import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { AboutAndService } from "@/components/about-and-service"
import { Merit } from "@/components/merit"
import { Support } from "@/components/support"
import { CaseStudies } from "@/components/case-studies"
import { Contact } from "@/components/contact"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <AboutAndService />
      <Merit />
      <Support />
      <CaseStudies />
      <Contact />
    </main>
  )
}

